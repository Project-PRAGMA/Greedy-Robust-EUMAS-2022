import base64
import contextlib
import copy
import hashlib
import itertools
import pprint
import random
from datetime import datetime
import seaborn as sns

from matplotlib import pyplot as plt
import re

pp = pprint.PrettyPrinter(indent=4)

abc_rules = ['seqphragmen', 'seqcc', 'seqpav', 'seqslav', 'rule-x']


def unique(l):
    result = []
    for i in l:
        if i not in result:
            result.append(i)
    return result


def convert_rule4paper(rule):
    if '_' in rule:
        rule, p = rule.split('_')
        return f"${p}$-{rule}"
    else:
        return rule


def grid_plot(data_df, col_name, row_name, plot_func, aspect=1.0, font_size=7, legend_ncol=1, legend_nrow=3,
              title_prefixes=None):
    col_values = unique(data_df[col_name].tolist())
    row_values = unique(data_df[row_name].tolist())
    nrows = len(row_values)
    ncols = len(col_values)
    plt.rcParams.update({'font.size': font_size})

    hcell = 2
    wcell = hcell * aspect

    htext = font_size / 25
    hlegend = htext * legend_nrow
    wspace = wcell / 10
    hspace = hcell / 10 + htext
    hframe = wcell / 10

    wfig = hframe + htext + (ncols * wcell) + (ncols - 1) * wspace + hframe
    hfig = hframe + hlegend + (nrows * hcell) + (nrows - 1) * (hspace) + hframe
    figsize = (wfig, hfig)

    grid_fig, axs = plt.subplots(figsize=figsize, nrows=nrows, ncols=ncols, squeeze=False)
    for rowix, row_value in enumerate(row_values):
        print(f"({rowix})", row_value)
        for colix, col_value in enumerate(col_values):
            is_last_row = rowix == nrows - 1
            is_col_central_even = ncols % 2 == 0 and colix == ncols / 2 - 1
            is_col_central_odd = ncols % 2 == 1 and colix == ncols / 2

            df = data_df.query(f"{col_name}==@col_value and {row_name}==@row_value")
            cur_ax = axs[rowix][colix]
            f = plot_func(df,
                          ax=cur_ax,
                          legend=is_last_row and (is_col_central_even or is_col_central_odd),
                          )

            sns.despine(left=True, bottom=True)

            col_prefix, row_prefix = ["", ""] if title_prefixes is None else title_prefixes
            title = " | ".join(x for x in [
                f"{col_prefix}{col_value}" if col_name is not None else None,
                f"{row_prefix}{row_value}" if row_name is not None else None
            ] if x is not None)
            f.set_title(title)

            # add a legend centrally
            if is_last_row:
                hanchor = - (hspace) / hcell
                if is_col_central_even:
                    f.legend(loc='upper center', bbox_to_anchor=(1, hanchor), ncol=legend_ncol)
                elif is_col_central_odd:
                    f.legend(loc='upper center', bbox_to_anchor=(0.5, hanchor), ncol=legend_ncol)
            else:
                f.set(xlabel=None)
                # f.set(xticklabels=[])

            if colix > 0:
                f.set(ylabel=None)
                f.set(yticklabels=[])

    grid_fig.subplots_adjust(left=(hframe + htext) / wfig, right=(wfig - hframe) / wfig,
                             top=(hfig - hframe - htext) / hfig, bottom=(hlegend + hframe) / hfig,
                             wspace=wspace / wcell, hspace=hspace / hcell)

    return grid_fig


def split_kwargs_by(dictionary, keys):
    """
    dictionary {a=[1,2,3], b=[5,6]} when keys=['a', 'b'] returns [{a=[1],b=[5]},{a=[2],b=[5]}...]
    """
    columns = [dictionary[k] for k in keys]
    split_list = list(itertools.product(*columns))
    ret = []
    for t in split_list:
        d = dictionary.copy()
        for k, v in zip(keys, t):
            d[k] = [v]
        ret.append(d)
    return ret
