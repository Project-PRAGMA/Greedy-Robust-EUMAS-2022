"""
COUNTING ROBUSTNESS RADIUS RAW - on top of abcvoting library / direct OWAGreedy:
 - synthesize the elections,
 - run all perturbation types
"""
import os
import random
from datetime import datetime
from itertools import groupby
from typing import List

import pandas as pd
from distributed import Client

import utils
from elections_raw import run_raw_elections, PrefProfile
from utils import grid_plot

COUNTING_RAW_CSV_FILENAME = 'counting_rradius_raw.csv'
COUNTING_RAW_ZIP_FILENAME = f'{COUNTING_RAW_CSV_FILENAME}.zip'

PERTURB_REMOVE = 'REMOVE'
PERTURB_ADD = 'ADD'
PERTURB_SWAP = 'SWAP'


def perturb(profile: PrefProfile, perturbation_level: float, perturbation_type: str):
    """
        for a perturbation level $l$, count of resources $n_r$, count of agents $n_a$, count of approving votes $n_v$,
        we randomly choose $l * n_v$ approvals to REMOVE from the list of existing approvals
        (or $l * (n_r * n_a - n_v)$ to ADD from all the non-approvals, or $l * n_v$ to SWAP from the list of existing approvals to the non-approvals).
        We also make sure that it is possible to perform the relevant operation, e.g. we limit the amount of added approvals to the count of empty approval votes.
    :param profile:
    :param perturbation_level:
    :param perturbation_type:
    :return:
    """
    new_profile = profile.deepcopy()

    if perturbation_type == PERTURB_REMOVE:
        approval_list = [(aix, rix) for aix, agent in enumerate(profile.preferences) for rix in agent.keys()]
        n_perturbations = int(perturbation_level * profile.approval_count())
        n_perturbations = min(n_perturbations, len(approval_list))
        approvals_to_remove = random.sample(approval_list, n_perturbations)
        for aix, rix in approvals_to_remove:
            agent = new_profile.preferences[aix]
            del agent[rix]

        # check we've removed the right amount
        assert new_profile.approval_count() == profile.approval_count() - n_perturbations

    elif perturbation_type in {PERTURB_ADD}:
        non_approval_list = [(aix, rix) for aix, agent in enumerate(profile.preferences) for rix in
                             range(profile.n_agents) if rix not in agent.keys()]
        n_perturbations = int(perturbation_level * len(non_approval_list))
        n_perturbations = min(n_perturbations, len(non_approval_list))
        approvals_to_add = random.sample(non_approval_list, n_perturbations)
        for aix, rix in approvals_to_add:
            agent = new_profile.preferences[aix]
            agent[rix] = 1

        # check we've added the right amount
        assert new_profile.approval_count() == profile.approval_count() + n_perturbations

    elif perturbation_type in {PERTURB_SWAP}:
        approval_list = [(aix, rix) for aix, agent in enumerate(profile.preferences) for rix in agent.keys()]
        n_perturbations = int(perturbation_level * profile.approval_count())
        n_perturbations = min(n_perturbations, profile.approval_count(), profile.size() - profile.approval_count())

        agent_func = lambda x: x[0]
        approvals_to_move = sorted(random.sample(approval_list, n_perturbations), key=agent_func)
        for aix, rix_iter in groupby(approvals_to_move, key=agent_func):
            agent = new_profile.preferences[aix]

            swap_from_ixs = set([rix for _, rix in rix_iter])
            swap_to_ixs_all = set(range(profile.n_resources)) - set(agent.keys())
            assert len(swap_to_ixs_all) >= len(swap_from_ixs), 'cannot swap, as there are too few empty slots'
            swap_to_ixs = random.sample(swap_to_ixs_all, len(swap_from_ixs))
            # print(aix, swap_from_ixs, swap_to_ixs)

            for swap_from, swap_to in zip(swap_from_ixs, swap_to_ixs):
                del agent[swap_from]
                agent[swap_to] = 1

        # check we've swapped the right amount
        assert new_profile.approval_count() == profile.approval_count(), f"new_profile has {new_profile.approval_count()} approvals, but the old had {profile.approval_count()} approvals "
    else:
        raise Exception(f"Perturbation type {perturbation_type} not implemented")

    return new_profile


def run_counting_rr_raw(
        perturbation_levels: List[float],
        perturbation_types: List[str],
        rules: List[str],
        n_elections: int,
        k: int,
        gen_profile_funcs,
        seed=None,
        flavour=None
):
    random.seed(seed)
    results = []
    for election_ix in range(n_elections):
        delta = n_elections / 10
        if election_ix % delta == 0:
            print(f"{election_ix}/{n_elections} @ {datetime.now().time()}")
        for gen_profile_func in gen_profile_funcs:
            profile = gen_profile_func()
            for rule in rules:
                base_winners, _ = run_raw_elections(profile, rule, k)
                base_winners_set = set(base_winners)
                for perturbation_type in perturbation_types:
                    for perturbation_level in perturbation_levels:
                        perturbed_profile = perturb(profile, perturbation_level, perturbation_type=perturbation_type)
                        winners, _ = run_raw_elections(perturbed_profile, rule, k)
                        candidates_changed = k - len(set(winners) & base_winners_set)
                        results.append(
                            dict(profile_key=profile.name,
                                 rule=rule,
                                 perturbation_type=perturbation_type,
                                 perturbation_level=perturbation_level,
                                 changed=(1 if candidates_changed > 0 else 0),
                                 candidates_changed=candidates_changed,
                                 )
                        )

    return pd.DataFrame(results)


def get_out_folder(target, flavour):
    return f"out/{target}/counting_rradius_raw/{flavour}"


def run_experiment(target, **kwargs):
    print(f"Running COUNTING-RRADIUS-RAW experiment")

    out_folder = get_out_folder(target, kwargs['flavour'])
    os.makedirs(out_folder, exist_ok=True)

    results_csv_filepath = f"{out_folder}/{COUNTING_RAW_ZIP_FILENAME}"

    print(f"Results will be saved to {results_csv_filepath}.")

    client = Client(threads_per_worker=1, n_workers=9)
    print(client)

    split_kwargs_list = (utils.split_kwargs_by(kwargs, ['gen_profile_funcs']))
    futures = [client.submit(run_counting_rr_raw, **split_kwargs)
               for split_kwargs in split_kwargs_list]

    df = pd.concat([fut.result() for fut in futures])

    compression_options = dict(method='zip', archive_name=f'{COUNTING_RAW_CSV_FILENAME}')
    df.to_csv(results_csv_filepath, compression=compression_options, index=False)

    print(kwargs)
    pd.set_option('max_colwidth', None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_rows', 40)
    print(df)

    visualise(target, flavour=kwargs['flavour'])


def aggregate_results(df):
    result = df.groupby(['profile_key', 'rule', 'perturbation_type', 'perturbation_level'], as_index=False).agg(
        {'changed': ['mean', 'std', 'count'], 'candidates_changed': ['mean', 'std']}
    )
    for stat in ['mean', 'std', 'count']:
        result[f'changed-{stat}'] = result['changed'][stat]
    for stat in ['mean', 'std']:
        result[f'candidates_changed-{stat}'] = result['candidates_changed'][stat]
    result.drop('changed', axis='columns', inplace=True)
    result.drop('candidates_changed', axis='columns', inplace=True)
    result.columns = result.columns.droplevel(level=1)
    return result


def visualise(target, flavour):
    out_folder = get_out_folder(target, flavour)

    csv_filepath = f"{out_folder}/{COUNTING_RAW_ZIP_FILENAME}"
    df = pd.read_csv(csv_filepath, compression='zip')

    df['rule'] = df.rule.apply(lambda x: utils.convert_rule4paper(x))

    df_grouped = aggregate_results(df)

    tex_filepath = f"{out_folder}/counting_rradius_raw.tex"

    tab_rows = []
    for ix, row in df_grouped.iterrows():
        ar = [str(cell) for cell in row]
        tab_rows.append(" & ".join(ar) + " \\\\")

    header_latex = "% " + " & ".join(df_grouped.columns) + " \\\\"

    table_latex = (
        "\n".join([header_latex] + tab_rows)
    )

    with open(tex_filepath, 'w+') as f:
        f.write(table_latex)

    print(f"Saved tex to {tex_filepath}.")

    import seaborn as sns
    df_fig = df
    # profile_header = lambda profile_key: ("-".join([v for k, v in [kv.split('=') for kv in profile_key.split('-')[1:]]])
    #                                      + f"")
    phi_extractor = lambda profile_key: profile_key.split("phi=")[1] if "phi=" in profile_key else "None"

    df_fig['phi'] = df_fig[['profile_key']].apply(lambda x: phi_extractor(*x), axis=1)

    row_header = lambda perturbation_type: f"{perturbation_type}"
    df_fig['perturbation_type'] = df_fig[['perturbation_type']].apply(lambda x: row_header(*x), axis=1)

    df_fig['perturbations (%)'] = df.perturbation_level * 100
    df_fig['elections changed (%)'] = df.changed * 100

    if "generated" in flavour:
        row = 'phi'
        style = 'perturbation_type'
        legend_ncol = 2
        font_size = 12
        title_prefixes = ["", "$\phi$="]
        profile_header = lambda profile_key: "$p=" + profile_key.split('-p=')[1][:3] + "$"
    else:
        row = 'perturbation_type'
        style = 'profile/elections'
        legend_ncol = 1
        font_size = 12
        title_prefixes = ["", ""]
        profile_header = lambda profile_key: (
            profile_key.replace("n_resources=", 'r').replace("n_agents=", 'a')
                .replace("approval_resampling", "resampling").split('-phi=')[0])

    df_fig['profile/elections'] = df_fig[['profile_key']].apply(lambda x: profile_header(*x), axis=1)
    df_fig['rule_fig'] = df_fig.rule.apply(lambda x: dict(seqphragmen="Phragmen", av='AV', pav='PAV', ccav='CC')[x])

    sns.set_theme(style="whitegrid", palette="bright", font_scale=1, context='notebook')

    f = grid_plot(df_fig, col_name='rule_fig', row_name=row,
                  font_size=font_size,
                  title_prefixes=title_prefixes,
                  legend_ncol=legend_ncol,
                  legend_nrow=3,
                  aspect=1.25,
                  plot_func=lambda df, ax, legend: sns.lineplot(data=df, ax=ax,
                                                                x='perturbations (%)',
                                                                y='elections changed (%)',
                                                                markers=True,
                                                                hue='profile/elections',
                                                                style=style,
                                                                legend=legend
                                                                ))

    fig_filepath = f"{out_folder}/counting_rradius_raw2.png"
    f.savefig(fig_filepath, dpi=200)
    print(f"Saved figure to: {fig_filepath}")

    df_fig['candidates changed'] = df.candidates_changed
    f = grid_plot(df_fig, col_name='rule_fig', row_name=row,
                  font_size=font_size,
                  title_prefixes=title_prefixes,
                  legend_ncol=legend_ncol,
                  legend_nrow=3,
                  aspect=1.25,
                  plot_func=lambda df, ax, legend: sns.lineplot(data=df, ax=ax,
                                                                x='perturbations (%)',
                                                                y='candidates changed',
                                                                markers=True,
                                                                hue='profile/elections',
                                                                style=style,
                                                                legend=legend
                                                                ))

    # f.set(xscale="log")
    fig_filepath = f"{out_folder}/counting_rradius_raw3candidates_changed.png"
    f.savefig(fig_filepath, dpi=200)
    print(f"Saved figure to: {fig_filepath}")


def get_cached_ml_profile_path(movie, target, flavour, election_utils):
    movielens_profiles_path = f"{get_out_folder(target, flavour)}/movielens_profiles"
    os.makedirs(movielens_profiles_path, exist_ok=True)
    cached_pref_profile_path = f"{movielens_profiles_path}/{movie}"
    if not os.path.exists(cached_pref_profile_path):
        PrefProfile.to_file(PrefProfile.from_search_term(
            election_utils, movie, max_resources=100, max_agents=100), cached_pref_profile_path)
    return cached_pref_profile_path


if __name__ == "__main__":

    for flavour, flavour_params in dict(
            generated=dict(
                gen_profile_funcs=[
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.25, p=0.1),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.5, p=0.1),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.75, p=0.1),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=1.0, p=0.1),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.25, p=0.3),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.5, p=0.3),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.75, p=0.3),
                    lambda: PrefProfile.generate_mapel(
                        n_resources=100, n_agents=100, model_id='approval_resampling', phi=1.0, p=0.3),
                ]),
    ).items():
        target = 'manual'
        run_experiment(
                           target=target,
                           flavour=flavour,
                           perturbation_levels=[0.0, 0.01, 0.05, .1, .2, .3, .4, .5, .6, .7, .8, .9, .95],
                           perturbation_types=[PERTURB_ADD, PERTURB_REMOVE],
                           rules=['av', 'pav', 'ccav', 'seqphragmen'],
                           n_elections=200,
                           k=10,
                           gen_profile_funcs=flavour_params['gen_profile_funcs'],
                           seed=13
        )
